int main()
{
	int n = 0;

	const int c1 = 0;
	const int c2 = 0;

	constexpr int c3 = 0;
	constexpr int c4 = 0;

}