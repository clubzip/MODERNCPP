// 11_rawstring
#include <iostream>
#include <string>

int main()
{
	std::string s1 = "\\\\.\\pipe\\server";
	std::string s2 = R"(\\.\pipe\server)";

	std::cout << s1 << std::endl;
	std::cout << s2 << std::endl;
}