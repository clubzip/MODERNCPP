// 3_�ӽð�ü1 - 77 page
#include <iostream>

class Point
{
public:
	int x, y;

	Point(int a, int b) { std::cout << "Point()" << std::endl; }
	~Point() { std::cout << "~Point()" << std::endl; }
};

// �ӽð�ü�� �Լ� ���� - 81 page
void draw_line(const Point& from, const Point& to) {}
void init(Point& pt) {}

int main()
{
	Point p1(1, 1);
	Point p2(5, 5);
	
	draw_line(p1, p2);

	std::cout << "-----" << std::endl;
}





