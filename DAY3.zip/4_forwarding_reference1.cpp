
// forwarding reference �� ?
// => "T&&" ���ø�

template<typename T> void chronomety(T&& a)
{
}

int main()
{

}