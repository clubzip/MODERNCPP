
template<typename T> void f1(T arg) {}

int main()
{
	f1(10);
	f1(3.4);
	f1(10, 3.4);
}
