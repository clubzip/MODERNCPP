int Factorial(int n)
{
	return n == 1 ? 1 : n * Factorial(n - 1);
}

int main()
{
	int n = 5;
	int s = Factorial(5);

	int arr1[Factorial(5)]; 

	int arr2[Factorial(n)]; 
						
	int s2 = Factorial(n); 
}