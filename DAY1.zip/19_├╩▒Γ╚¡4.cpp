class Point
{
	int x, y;
public:
	Point(int a, int b) : x(a), y(b) {}
};

void f1(int n) {}
void f2(Point pt) {}

int main()
{
	f1(3);

	f2(? );
}

Point f3() 
{ 
	return Point(1, 2); 
}
