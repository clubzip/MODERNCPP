#include <vector>
#include <string>
#include <memory>

void goo(std::vector<int> v) {}
void hoo(std::string s) {}

int main()
{
	hoo("hello");

	std::string s1("hello");
	std::string s2 = "hello";

	

	goo(10);	
	std::vector<int> v1(10);  
	std::vector<int> v2 = 10; 

}





